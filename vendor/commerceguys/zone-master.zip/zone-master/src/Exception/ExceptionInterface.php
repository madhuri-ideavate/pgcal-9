<?php

namespace CommerceGuys\Zone\Exception;

interface ExceptionInterface
{
}
